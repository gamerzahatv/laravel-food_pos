<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6 lg:p-8 bg-white border-b border-gray-200">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block h-12 w-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-12 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <h1 class="mt-8 text-2xl font-medium text-gray-900">
                        ยินดีต้อนรับสู่หน้าจัดการสินค้า!
                    </h1>

                    <p class="mt-6 text-gray-500 leading-relaxed">
                        ท่านสามารถ เพิ่ม-ลบ-แก้ไข จัดการสินค้า
                        <i class="fa-solid fa-user"></i>

                    </p>
                </div>

                <div class="py-12">
                    <div class="container text-center">
                        <div class="row">
                            <div class="col">
                                <div class="input-group rounded">
                                    <input type="search" class="form-control rounded" placeholder="Search"
                                        aria-label="Search" aria-describedby="search-addon" />
                                    <button type="button" class="btn btn-outline-primary">search</button>
                                </div>
                            </div>
                            <div class="col">
                                <div class="d-grid gap-2">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-outline-success" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop" style="color:black;">
                                        เพิ่มสินค้า
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <section class="intro py-2">
                        <div class="mask d-flex align-items-center h-100">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-12">
                                        <div class="card shadow-2-strong">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table mb-0 table-bordered ">
                                                        <thead style="background:#cccaca90; ">
                                                            <tr class="text-center">
                                                                <th scope="col">รูปสินค้า</th>
                                                                <th scope="col">ไอดีสินค้า</th>
                                                                <th scope="col">ชื่อสินค้า</th>
                                                                <th scope="col">ราคา</th>
                                                                <th scope="col">ประเภท</th>
                                                                <th scope="col">เพิ่มเมื่อ</th>
                                                                <th scope="col">แก้ไขเมื่อ</th>
                                                                <th scope="col">จัดการ</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody style="background-color: #ffffff;">
                                                            <?php $__currentLoopData = $fetch_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <!--loop-->
                                                                <tr class="text-center">
                                                                    <td><img src="<?php echo e(asset($row->product_image)); ?>"
                                                                            class="img-thumbnail rounded mx-auto d-block "
                                                                            style="max-width:120px;max-height:120px; min-width:120px;min-height:120px;">
                                                                    </td>
                                                                    <td><?php echo e($row->product_id); ?></td>
                                                                    <td><?php echo e($row->product_name); ?></td>
                                                                    <td><?php echo e($row->product_price); ?></td>
                                                                    <td><?php echo e($row->product_type); ?></td>
                                                                    <td><?php echo e($row->created_at); ?></td>
                                                                    <td><?php echo e($row->updated_at); ?></td>
                                                                    <td>
                                                                        <div class="btn-group" role="group"
                                                                            aria-label="Basic mixed styles example">
                                                                            <a
                                                                                href="<?php echo e(url('/admin/adminproductinfo/' . $row->id)); ?>"><button
                                                                                    type="button"
                                                                                    class="btn btn-success"style="color:black; margin:2px"><i
                                                                                        class="fa-solid fa-eye"></i></button></a>


                                                                            <button type="button" class="btn btn-primary edit_product" id="<?php echo e($row->id); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal" style="margin:2px ">
                                                                                <i class="fa-sharp fa-solid fa-pen-to-square" style="color:black"></i>
                                                                            </button>
                                                                            
                                                                            <button type="button"
                                                                                class="btn btn-danger del_product"style="color:black; margin:2px"
                                                                                id="<?php echo e($row->id); ?>"><i
                                                                                    class="fa-regular fa-trash-can"></i></button>
                                                                        </div>
                                                                        <h1 id="demo"></h1>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>

                                                </div>
                                                <br>
                                                <div class="d-flex justify-content-center">
                                                    <?php echo e($fetch_product->links()); ?>

                                                    <!-- number page -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">เพิ่มสินค้า</h1>
                <button type="button" onclick="clearmodal()" class="btn btn-danger" data-bs-dismiss="modal"
                    aria-label="Close" style="background:red;">ปิด</button>

            </div>
            <div class="modal-body">

                <form action="<?php echo e(route('addproduct')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="container">
                        <img id="frame" src="" class="img-thumbnail rounded mx-auto d-block "
                            style="max-width:200px;max-height:200px; min-width:200px;min-height:200px;" />
                        <div class="mb-5 "style="margin:auto;   margin: auto; width: 50%; text-align: center;">
                            <br>
                            <input class="form-control" type="file" name="image_product" id="formFile"
                                accept="image/x-png,image/jpeg" onchange="preview()" style="">
                            <!-- <button onclick="clearImage()" class="btn btn-primary mt-3">กลับรูปภาพค่าเริ่มต้น</button>-->
                        </div>
                        <script>
                            function preview() {
                                frame.src = URL.createObjectURL(event.target.files[0]);
                            }
                            /* function clearImage() {
                                document.getElementById('formFile').value = null;
                                frame.src = "https://cdn-icons-png.flaticon.com/512/2927/2927347.png";
                            }*/
                        </script>
                    </div>
                    <!-- Text input -->
                    <div class="form-outline mb-4">
                        <input type="text" id="id_product_field" name="id_product" class="form-control"
                            placeholder="ไอดีสินค้า" required="" />
                        <?php $__errorArgs = ['id_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert">
                                A simple danger alert—check it out!
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Text input -->
                    <div class="form-outline mb-4">
                        <input type="text" id="name_product_field" name="name_product" class="form-control"
                            placeholder="ชื่อสินค้า" required="" />
                        <?php $__errorArgs = ['name_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert">
                                A simple danger alert—check it out!
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Number input -->
                    <div class="form-outline mb-4">
                        <input type="number" id="price_product_field" name="price_product" class="form-control"
                            placeholder="ราคาสินค้า" required="" />
                        <?php $__errorArgs = ['price_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert">
                                A simple danger alert—check it out!
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Message input -->
                    <div class="form-outline mb-4">
                        <textarea class="form-control" id="desc_product_field" name="desc_product" rows="4" required=""></textarea>
                        <label class="form-label" for="form6Example7">คำอธิบายสินค้า</label>
                        <?php $__errorArgs = ['desc_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert">
                                A simple danger alert—check it out!
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-outline mb-4">
                        <div class="container text-center">
                            <label for="html">เลือกประเภทอาหาร</label><br>
                            <select name="typelist_product" required>
                                <option value="" disabled selected style=" display: none;"></option>
                                <option value="กับข้าว">กับข้าว</option>
                                <option value="เมนูเส้น">เมนูเส้น</option>
                                <option value="ข้าวผัด">ข้าวผัด</option>
                                <option value="สเน็คบ๊อก">สเน็คบ๊อก</option>
                                <option value="ของหวาน">ของหวาน</option>
                                <option value="เครื่องดื่ม">เครื่องดื่ม</option>
                            </select>
                        </div>

                    </div>
                    <button type="reset" value="reset" class="btn btn-secondary"
                        style="color:black; background-color: rgb(200, 190, 190);">reset</button>
                    <script>
                        function clearmodal() {
                            var getValue1 = document.getElementById("id_product_field");
                            var getValue2 = document.getElementById("name_product_field");
                            var getValue3 = document.getElementById("price_product_field");
                            var getValue4 = document.getElementById("desc_product_field");
                            getValue1.value = "";
                            getValue2.value = "";
                            getValue3.value = "";
                            getValue4.value = "";
                        }
                    </script>
                    <button type="submit" class="btn btn-success"
                        style="color:black; background-color: rgb(96, 234, 96);">submit
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- modal edit product-->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">แก้ไขสินค้า</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form action="<?php echo e(route('productedit')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <img id="get_id_edit_image" src="" class="img-thumbnail rounded mx-auto d-block "
                        style="max-width:200px;max-height:200px; min-width:200px;min-height:200px;" />
                    <div class="mb-5 "style="margin:auto;   margin: auto; width: 50%; text-align: center;">
                        <br>
                        <input class="form-control" type="file" name="imageedit_product" id="formFile"
                            accept="image/x-png,image/jpeg" onchange="preview()" style="">
                    </div>
                    <script>
                        function preview() {
                            frame.src = URL.createObjectURL(event.target.files[0]);
                        }
                    </script>
                </div>
                <!--true_id product-->
                <input type="text" id="get_id_product_edit" name="get_id_product" class="form-control"
                        placeholder="ไอดีสินค้า" required="" />
                <!-- Text input -->
                <div class="form-outline mb-4">
                    <label class="form-label">ไอดีสินค้า</label>
                    <input type="text" id="get_id_edit" name="id_product" class="form-control"
                        placeholder="ไอดีสินค้า" required="" />
                    <?php $__errorArgs = ['id_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            A simple danger alert—check it out!
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Text input -->
                <div class="form-outline mb-4">
                    <label class="form-label">ชื่อสินค้า</label>
                    <input type="text" id="get_id_name_edit" name="name_product" class="form-control"
                        placeholder="ชื่อสินค้า" required="" />
                    <?php $__errorArgs = ['name_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            A simple danger alert—check it out!
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Number input -->
                <div class="form-outline mb-4">
                    <label class="form-label">ราคาสินค้า</label>
                    <input type="number" id="get_id_price_edit" name="price_product" class="form-control"
                        placeholder="ราคาสินค้า" required="" />
                    <?php $__errorArgs = ['price_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            A simple danger alert—check it out!
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Message input -->
                <div class="form-outline mb-4">
                    <label class="form-label">คำอธิบายสินค้า</label>
                    <textarea class="form-control" id="get_id_desc_edit" name="desc_product" rows="4" required=""></textarea>
                    <?php $__errorArgs = ['desc_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            A simple danger alert—check it out!
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-outline mb-4">
                    <div class="container text-center">
                        <label for="html">เลือกประเภทอาหาร</label><br>
                        <select name="typelist_product" id = "get_id_select_edit" required >
                            <option value="" disabled selected style=" display: none;"></option>
                            <option value="กับข้าว">กับข้าว</option>
                            <option value="ไก่">ไก่</option>
                            <option value="สแน็คบ๊อก">สแน็คบ๊อก</option>
                            <option value="ของหวาน">ของหวาน</option>
                            <option value="เครื่องดื่ม">เครื่องดื่ม</option>
                        </select>
                    </div>

                </div>
                <button type="reset" value="reset" class="btn btn-secondary"
                    style="color:black; background-color: rgb(200, 190, 190);">reset</button>
                <script>
                    function clearmodal() {
                        var getValue1 = document.getElementById("id_product_field");
                        var getValue2 = document.getElementById("name_product_field");
                        var getValue3 = document.getElementById("price_product_field");
                        var getValue4 = document.getElementById("desc_product_field");
                        getValue1.value = "";
                        getValue2.value = "";
                        getValue3.value = "";
                        getValue4.value = "";
                    }
                </script>
                <button type="submit" class="btn btn-success"
                    style="color:black; background-color: rgb(96, 234, 96);">submit
                </button>
            </form>
        </div>
      </div>
    </div>
  </div>
<script>

    $('.edit_product').click(function() {
        $('#exampleModal').modal('show');
            var get_product_edit_id = $(this).attr("id");
            var url_product_edit = '<?php echo e(route('getproduct', ':id')); ?>';
            url_product_edit = url_product_edit.replace(':id', get_product_edit_id);
            $.ajax({
                    url: url_product_edit,
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    enctype: 'multipart/form-data',
                    data: {
                        id: get_product_edit_id
                    },
                    success: function(data) {
                        $('#get_id_edit_image').attr('src', data.product_image);
                        $('#get_id_product_edit').val(data.id); 
                        $('#get_id_edit').val(data.product_id); 
                        $('#get_id_name_edit').val(data.product_name); 
                        $('#get_id_price_edit').val(data.product_price); 
                        $('#get_id_desc_edit').val(data.product_desc);  
                        $('#get_id_select_edit').val(data.product_type); 
                                        
                    }
            });

    });

    //Edit form
    $(".del_product").click(function() {
        Swal.fire({
            allowOutsideClick: false,
            title: 'คุณยืนยันที่จะลบสินค้านี้หรือไม่?',
            text: "กดยืนยันเพื่อลบข้อมูล!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: 'ยกเลิก',
            confirmButtonText: 'ยืนยัน!'
        }).then((result) => {
            var get_product_del_id = $(this).attr("id");
            var url_product_del = '<?php echo e(route('productdel', ':id')); ?>';
            url_product_del = url_product_del.replace(':id', get_product_del_id);
            if (result.isConfirmed) {
                $.ajax({
                    url: url_product_del,
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    enctype: 'multipart/form-data',
                    data: {
                        id: get_product_del_id
                    },
                    success: function() {
                        Swal.fire(
                            'กำลังทำการลบ!',
                            'ลบบัญชีผู้ใช้เสร็จสิ้น',
                            'success'
                        )
                        

                        setTimeout(location.reload.bind(location), 1500);
                    }
                });

            }
        })
    });
</script>

<?php /**PATH C:\xampp\htdocs\hellkitchen\resources\views/admin/admin_product.blade.php ENDPATH**/ ?>