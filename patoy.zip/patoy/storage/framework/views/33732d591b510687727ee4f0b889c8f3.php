<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('ประวัติการสั่งซื้อ')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6 lg:p-8 bg-white border-b border-gray-200">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block h-12 w-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-12 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <h1 class="mt-8 text-2xl font-medium text-gray-900">
                        ยินดีต้อนรับสู่หน้าประวัติการสั่งซื้อ!
                    </h1>

                </div>

                <div class="card">
                    <div class="card-body">
                      <div class="container mb-5 mt-3">
                        <div class="row d-flex align-items-baseline">
                          <div class="col-xl-9">
                            <p style="color: #7e8d9f;font-size: 20px;">ไอดีออเดอร์ >> <strong>ID:  <?php echo e($orderDetailsadmin[0]->order_id); ?></strong></p>
                          </div>
                          <div class="col-xl-3 float-end">
                            <a class="btn btn-light text-capitalize border-0" data-mdb-ripple-color="dark"><i
                                class="fas fa-print text-primary"></i> Print</a>
                            <a class="btn btn-light text-capitalize" data-mdb-ripple-color="dark"><i
                                class="far fa-file-pdf text-danger"></i> Export</a>
                          </div>
                          <hr>
                        </div>
                  
                        <div class="container">
                          <div class="col-md-12">
                            <div class="text-center">
                              <i class="fab fa-mdb fa-4x ms-0" style="color:#5d9fc5 ;"></i>
                              <p class="pt-0">MDBootstrap.com</p>
                            </div>
                  
                          </div>
                  
                  
                          <div class="row">
                            <div class="col-xl-8">
                              <ul class="list-unstyled">
                                <li class="text-muted">คุณ: <?php echo e($orderDetailsadmin[0]->name); ?> <span style="color:#5d9fc5 ;"></span></li>
                                <li class="text-muted">Street, City (บิท)</li>
                                <li class="text-muted">State, Country (บิท)</li>
                                <li class="text-muted"><i class="fas fa-phone"></i> 123-456-789 (บิท)</li>
                              </ul>
                            </div>
                            <div class="col-xl-4">
                              <p class="text-muted">รายละเอียด</p>
                              <ul class="list-unstyled">
                                <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                                    class="fw-bold">ไอดีออเดอร์: <?php echo e($orderDetailsadmin[0]->order_id); ?></span> </li>
                                <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                                    class="fw-bold">สั่งซื้อวันที่: <?php echo e($orderDetailsadmin[0]->date_created); ?></span> </li>
                                <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                                    class="me-1 fw-bold">สถานะ:</span><span class="badge bg-warning text-black fw-bold">
                                    จ่ายแล้ว</span></li>
                              </ul>
                            </div>
                          </div>
                  
                          <div class="row my-2 mx-1 justify-content-center">
                            <table class="table table-striped table-borderless">
                              <thead style="background-color:#84B0CA ;" class="text-white">
                                
                                <tr>
                                  <th scope="col">#</th>
                                  <th scope="col">รูป</th>
                                  <th scope="col">ชื่อสินค้า</th>
                                  <th scope="col">ราคาสินค้าต่อหน่วย</th>
                                  <th scope="col">จำนวน</th>
                                  <th scope="col">ยอดสินค้า</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $sum = 0 ?>
                                <?php $__currentLoopData = $orderDetailsadmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                
                                  <?php $sum += 1 ?>
                                <tr>
                                  <th scope="row"><?php echo e($sum); ?></th>
                                  <td width="20%">

                                    <img src="<?php echo e($items->product_image); ?>" width="90">

                                  </td>
                                  <td><?php echo e($items->product_name); ?></td>
                                  <td><?php echo e($items->product_price); ?></td>
                                  <td><?php echo e($items->quantity); ?></td>
                                  <td><?php echo e($items->result_amount); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                              </tbody>
                             
                            </table>
                          </div>
                          <div class="row">
                            <div class="col-xl-8">
                              <p class="ms-3">ขอบคุณที่สั่งซื้อสินค้า</p>
                  
                            </div> 
                            <div class="col-xl-3">
                              <!-- <ul class="list-unstyled">
                                <li class="text-muted ms-3"><span class="text-black me-4">SubTotal</span>$1110</li>
                                <li class="text-muted ms-3 mt-2"><span class="text-black me-4">Tax(15%)</span>$111</li>
                              </ul> -->
                              <p class="text-black float-start"><span class="text-black me-3"> รวมรายจ่ายทั้งหมด</span><span
                                  style="font-size: 25px;"><?php echo e($items->total); ?> บาท</span></p>
                            </div>
                          </div>
                          <hr>
                          <div class="row">
                            <div class="col-xl-10">
                                <br>
                                <a href="<?php echo e(url('/admin/orderhistory')); ?>" ><button type="button" class="btn btn-outline-success">ย้อนกลับ</button></a>
                            </div>

                          </div>
                  
                        </div>
                      </div>
                    </div>
                  </div>


            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hellkitchen\resources\views/admin/admin_order_info.blade.php ENDPATH**/ ?>