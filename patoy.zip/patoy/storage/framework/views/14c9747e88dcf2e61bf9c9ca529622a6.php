

    
        <!-- ======= Portfolio Section ======= -->
        <section id="portfolio" class="portfolio sections-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-header">
                    <h2>เมนูยอดนิยม</h2>
                </div>

                <div class="portfolio-isotope" data-portfolio-filter="*" data-portfolio-layout="masonry" data-portfolio-sort="original-order" data-aos="fade-up" data-aos-delay="100">

                    <div>
                        <ul class="portfolio-flters">
                            <li data-filter="*" class="filter-active">เมนูยอดนิยมทั้งหมด</li>
                            <li data-filter=".filter-app">กับข้าว</li>
                            <li data-filter=".filter-product">เมนูเส้น</li>
                            <li data-filter=".filter-branding">ข้าวผัด</li>
                            <li data-filter=".filter-books">เครื่องดื่ม</li>
                        </ul><!-- End Portfolio Filters -->
                    </div>


                    <h1>test</h1>
                    <div class="row gy-4 portfolio-container">
                        <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-4 col-md-6 portfolio-item filter-app">
                            <div class="portfolio-wrap">
                                <a href="https://s359.thaibuffer.com/rq/580/435/50/pagebuilder/dbc77e85-1cb6-44ff-a3d8-dc6b21f59d5a.jpg" data-gallery="portfolio-gallery-app" class="glightbox"><img src="https://s359.thaibuffer.com/rq/580/435/50/pagebuilder/dbc77e85-1cb6-44ff-a3d8-dc6b21f59d5a.jpg" class="img-fluid" alt=""></a>
                                <div class="portfolio-info ">
                                    <div class="container text-center ">
                                        <h4><a href="portfolio-details.html" title="More Details">App 1</a></h4>
                                    </div>
                                    <br>
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'User')): ?>
                                            <div class="container text-center ">
                                                <a href="" class="d-flex mb-3 btn  btn-warning">
                                                    <div class="me-auto p-2">100 ฿</div>
                                                    <div class="p-2"></div>
                                                    <div class="p-2">+เลือก</div>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                            
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="container text-center ">
        
                                            <a  class = "d-flex mb-3 btn  btn-warning text-center justify-content-center" href="<?php echo e(url('/buyer/login')); ?>">
                                                ลงชื่อเข้าใช้
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

            </div>
            

        </section>

        

    </main><!-- End #main --><?php /**PATH C:\xampp\htdocs\hellkitchen\resources\views/components/indexcomponent/index_body.blade.php ENDPATH**/ ?>