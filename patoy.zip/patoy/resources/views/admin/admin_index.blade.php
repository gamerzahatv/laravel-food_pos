<x-app-layout>
    <x-admin.welcome_admin  />                   
</x-app-layout>