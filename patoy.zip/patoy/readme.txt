ลากไฟล์  migrate.bat และ  refresh_table ไปใส่ในโฟลเดอร์โปรเจค

ให้รันไฟล์  migrate.bat
import database ในโฟลเดอร์ database backup เป็นไฟล์ .xml


ถ้ามีปัญหารันไฟล์ refresh_table
import database ในโฟลเดอร์ database backup เป็นไฟล์ .xml

รัน  php artisan serve --host=ไอพีคุณ --port=พอตคุณ   เพื่อดูเว็บ



เข้า admin
admin@gmail.com
12345678


เข้าuser
user@gmail.com
12345678