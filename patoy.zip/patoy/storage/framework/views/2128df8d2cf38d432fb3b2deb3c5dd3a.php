<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-6 lg:p-8 bg-white border-b border-gray-200">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block h-12 w-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-12 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <h1 class="mt-8 text-2xl font-medium text-gray-900">
                        ยินดีต้อนรับสู่หน้าจัดการลูกค้า!
                    </h1>

                    <p class="mt-6 text-gray-500 leading-relaxed">
                        ท่านสามารถ ใช้ ★ เพื่อปรับแต่งยศ หรือใช้เครื่องมือในหมวดปรับแต่งเพื่อ แก้ไข-ลบ จัดการลูกค้า
                    </p>
                </div>

                <div class="py-12">
                    <div class="container text-center">
                        <div class="row">
                            <div class="col">
                                <div class="input-group rounded">
                                    <input type="search" class="form-control rounded" placeholder="Search"
                                        aria-label="Search" aria-describedby="search-addon" />
                                    <button type="button" class="btn btn-outline-primary">search</button>
                                </div>
                            </div>
                            <div class="col">
                                <div class="d-grid gap-2">

                                </div>
                            </div>
                        </div>
                    </div>
                    <section class="intro py-2">
                        <div class="mask d-flex align-items-center h-100">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-12">
                                        <div class="card shadow-2-strong">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table mb-0 table-bordered ">
                                                        <thead style="background:#cccaca90; ">
                                                            <tr class="text-center">
                                                                <th scope="col">รูปผู้ใช้</th>
                                                                <th scope="col">ไอดีผู้ใช้</th>
                                                                <th scope="col">ชื่อ</th>
                                                                <th scope="col">เบอร์โทรศัพท์</th>
                                                                <th scope="col">ที่อยู่</th>
                                                                <th scope="col">สร้างเมื่อ</th>
                                                                <th scope="col">แก้ไขเมื่อ</th>
                                                                <th scope="col">ยศ</th>
                                                                <th scope="col">ปรับแต่ง</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody style="background-color: #ffffff;">
                                                            <?php $__currentLoopData = $fetch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <!--loop-->
                                                                <tr class="text-center">
                                                                    <td><img src="<?php echo e(asset($row->profile_photo_path)); ?>"
                                                                        class="img-thumbnail rounded mx-auto d-block "
                                                                        style="max-width:120px;max-height:120px; min-width:120px;min-height:120px;">
                                                                    </td>
                                                                    <td><?php echo e($row->id); ?></td>
                                                                    <td><?php echo e($row->name); ?></td>
                                                                    <td>เบอร์โทรศัพท์</td>
                                                                    <td>ที่อยู่</td>
                                                                    <td><?php echo e($row->created_at); ?></td>
                                                                    <td><?php echo e($row->updated_at); ?></td>
                                                                    <td><?php echo e($row->role_name); ?></td>

                                                                    <td>
                                                                        <div class="btn-group" role="group"
                                                                            aria-label="Basic mixed styles example">
                                                                            <a
                                                                                href="<?php echo e(url('/admin/adminuserinfo/' . $row->id)); ?>">
                                                                                <button type="button"
                                                                                    class="btn btn-success"style="color:black; margin:2px"><i
                                                                                        class="fa-solid fa-eye"></i></button>
                                                                            </a>
                                                                            <button type="button"
                                                                                id="<?php echo e($row->id); ?>"
                                                                                class="btn btn-danger deluser"style="color:black; margin:2px"><i
                                                                                    class="fa-solid fa-trash"></i>
                                                                            </button>

                                                                            <button type="button"
                                                                                class="btn btn-primary rolepage"
                                                                                id="<?php echo e($row->id); ?>"
                                                                                style="color:black; margin:2px"><i
                                                                                    class="fa-solid fa-star"></i>
                                                                            </button>

                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </tbody>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<!-- modal -->
<div class="modal fade" id="rolechange" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">ปรับยศของบัญชีผู้ใช้</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="role_user_id" id="get_id_role" val="">
                <button type="button" class="btn btn-outline-warning" id="admin_bu">แอดมิน</button>
                <button type="button" class="btn btn-outline-warning" id="user_bu">ผู้ใช้ทั่วไป</button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
    $(function() {
        $(".rolepage").click(function() {
            var get_user_id = $(this).attr("id");
            $('#rolechange').modal('show');

            $('#admin_bu').click(function() {
                var url = '<?php echo e(route('adminrole', ':id')); ?>';
                url = url.replace(':id', get_user_id);
                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    enctype: 'multipart/form-data',
                    data: {
                        id: get_user_id
                    },
                    success: function() {
                        Swal.fire({
                            icon: 'success',
                            title: 'เปลี่ยนบัญชีเป็นแอดมินสำเร็จ',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        $("#rolechange").modal('hide');
                        setTimeout(location.reload.bind(location), 1500);
                    }
                });
            });

            $('#user_bu').click(function() {
                var url = '<?php echo e(route('userrole', ':id')); ?>';
                url = url.replace(':id', get_user_id);

                $.ajax({
                    url: url,
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    enctype: 'multipart/form-data',
                    data: {
                        id: get_user_id
                    },
                    success: function() {
                        Swal.fire({
                            icon: 'success',
                            title: 'เปลี่ยนบัญชีเป็นผู้ใช้สำเร็จ',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        $("#rolechange").modal('hide');
                        setTimeout(location.reload.bind(location), 1500);
                    }
                });
            });
        });


    });

    //delete button
    $(".deluser").click(function() {
        Swal.fire({
            allowOutsideClick: false,
            title: 'คุณยืนยันที่จะลบผู้ใช้นี้หรือไม่?',
            text: "กดยืนยันเพื่อลบข้อมูล!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: 'ยกเลิก',
            confirmButtonText: 'ยืนยัน!'
        }).then((result) => {
            var get_user_del_id = $(this).attr("id");
            var url_user_del = '<?php echo e(route('userdel', ':id')); ?>';
            url_user_del = url_user_del.replace(':id', get_user_del_id);
            if (result.isConfirmed) {
                $.ajax({
                    url: url_user_del,
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    enctype: 'multipart/form-data',
                    data: {
                        id: get_user_del_id
                    },
                    success: function() {
                        Swal.fire(
                            'กำลังทำการลบ!',
                            'ลบบัญชีผู้ใช้เสร็จสิ้น',
                            'success'
                        )
                        setTimeout(location.reload.bind(location), 1500);
                    }
                });

            }
        })
    });

    $(".deluser").click(function() {
    });
</script>
<?php /**PATH C:\xampp\htdocs\hellkitchen\resources\views/admin/admin_user.blade.php ENDPATH**/ ?>